let title = document.querySelector("#modal-title");
let price = document.querySelector(".pricing");
let image = document.querySelector(".modal-pic");
let btn = document.querySelector(".buy-link");
let links = document.querySelectorAll(".card-link")

links.forEach(function(link){
    link.addEventListener("click", function(e){
        console.log('works');
        clickEvent(e);
    })
})

async function clickEvent(link){
    var card = link.target.closest('.card-body');
    var location = card.querySelector('h4').textContent;

    try {
        let response = await fetch("purchases.json");
        let data = await response.json();

        for(let i = 0; i <= 6; i++){
            if(location == data[i].title){
                title.textContent = data[i].title;
                price.textContent = data[i].price;
                image.src = data[i].image;
                btn.href = data[i].link;
            }
        }
    } catch(error){
        console.log('there was an error', error);
    }
}
